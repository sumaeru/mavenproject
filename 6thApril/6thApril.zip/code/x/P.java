package x;

public class P {

    public P()
    {
        System.out.println("P object created");
    }
}
