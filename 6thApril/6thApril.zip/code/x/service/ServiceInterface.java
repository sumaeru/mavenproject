package x.service;

public interface ServiceInterface {
}
