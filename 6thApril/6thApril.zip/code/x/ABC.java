package x;

public class ABC {



    public ABC()
    {
        System.out.println("ABC object created");

    }


    public void setS(Y  y)
    {
        System.out.println("wiring done by spring");
    }

    public void ritual() {

        System.out.println("core java never out of fashion");
    }
}
