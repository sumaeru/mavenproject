package project.service;

import project.model.Model;

public interface ServiceInterface {
    void addResource(Model model);

    Model viewResource();
}
