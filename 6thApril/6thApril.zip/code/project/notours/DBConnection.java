package project.notours;

public class DBConnection {
    public DBConnection()
    {
        System.out.println("getting connected to DB");
    }

}
