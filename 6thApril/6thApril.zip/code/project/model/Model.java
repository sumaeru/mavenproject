package project.model;

public class Model {
}
