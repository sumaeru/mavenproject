package lc;

public class Sim {
}
