package lc;

public class Mobile {

    private Sim sim; // data that it is association
    private Battery b;  // data

    public Mobile(Sim sim)
    {
        b =new Battery();  //composition
        this.sim = sim; // aggregation

    }



}
