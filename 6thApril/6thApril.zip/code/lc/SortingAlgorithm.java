package lc;

public interface SortingAlgorithm {
    void sort();
}
