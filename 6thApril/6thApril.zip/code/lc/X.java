package lc;

public class X {

    public static void scrap()
    {
        System.out.println("junk function in class X");

    }
}
