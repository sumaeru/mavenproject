package lc;

public class Battery {
}
