package x;

public class Y {

    public Y()
    {
        System.out.println("Y object created");
    }
}
