package x.controller;

public class Presnetation {

    private ServiceInterface serviceInterface;  //association

    public Presentation(ServiceInterface serviceInterface)
    {
        this.serviceInterface = serviceInterface;
    }


}
