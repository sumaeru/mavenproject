package lc;

public class BubbleSort implements SortingAlgorithm {
    @Override
    public void sort() {

        System.out.println("bubble sort at work");

    }
}
