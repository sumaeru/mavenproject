package lc;

public class MergeSort implements SortingAlgorithm {


    @Override
    public void sort() {
        System.out.println("merge sort at work");

    }
}
