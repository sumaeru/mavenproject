package poc.issuperimportant.whenindoubt;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import poc.model.A;

public class HeySpringPleaseWork {

    public static void main(String[] args) {

        ApplicationContext c =new ClassPathXmlApplicationContext("carrot.xml");






    }
}
