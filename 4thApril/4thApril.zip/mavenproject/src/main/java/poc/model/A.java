package poc.model;


public class A {

    public A()
    {
        System.out.println("A object created");//stupid code
    }


    //wiring of B has been done in A
    public void setGreat(B b)
    {
        System.out.println("SEt great called");
    }
}
