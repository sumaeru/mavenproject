package poc.model;

public class B {

    public B()
    {
        System.out.println("B object created");
    }
}
