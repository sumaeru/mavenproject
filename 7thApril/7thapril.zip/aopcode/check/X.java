package check;


//Target on which we need to apply the logic
public class X {
	
	public void freak1()
	{
		System.out.println("freak function in class X");
	}
	
	public void freak2()
	{
		System.out.println("decent function");
	}

}
