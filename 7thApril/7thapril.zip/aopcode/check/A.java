package check;

public class A {
	
	public A() { System.out.println("A created"); }

	public void aa(int x) { System.out.println(" aa  of A"); }
	public void f1() { System.out.println("f1 funtion of A");}

}
