package check;

public class SomeLogic {
	
	public SomeLogic() { System.out.println("some logic created"); }
	
	public void a1()
	{
		System.out.println("Transaction started");
		
	}
	
	public void a2()
	{
		System.out.println("transaction ended");
		
	}

}
