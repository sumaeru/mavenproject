package check;

public class B {
	public B() { System.out.println("B created"); }
	
	public void aa() { System.out.println("aa of B "); }
	public void f3() { System.out.println("f3 function of B");}

}
