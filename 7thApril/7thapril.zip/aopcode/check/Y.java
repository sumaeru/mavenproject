package check;

public class Y {
	
	public void freakf3()
	{
		System.out.println("freak function in class Y");
	}

}
