package check;

public class Z {

}
