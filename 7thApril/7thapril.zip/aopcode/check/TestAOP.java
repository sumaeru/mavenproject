package check;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAOP {
	
	
	public static void main(String[] args) {
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext(
			      "repeat.xml");
		
		B obj = context.getBean(B.class);
		obj.aa();
		
		
		A a = context.getBean(A.class);
		a.aa(3);
	
		
		

		
		
		
	}
	
	
	public static void main1(String[] args) {
	
		ApplicationContext context = new ClassPathXmlApplicationContext(
			      "applicationcontext.xml");
		
		
		X obj =context.getBean(X.class);
		
		String name = obj.getClass().getName(); //in this case this is useless
		
		System.out.println(name);
		obj.freak1();
		obj.freak2();
		
	
		
		
	}
	
}	