package check;


//what is the logic I plan to apply across set of fucntions.
public class LogA {
	
	public void wc()
	{
		System.out.println("security started");
	}
	
	public void cc()
	{
		System.out.println("security ended");
	}
	
	

}
