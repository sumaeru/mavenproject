package freak;

import java.util.Arrays;

public class XTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x[]= {2,3,1,7};
		int search=7;
		Arrays.sort(x);
		int pos = Arrays.binarySearch(x, search);
		if( pos >=0)
				System.out.println("found at " + pos);
		else
			System.out.println("not found");
		
		
		
		
		
	}

}
